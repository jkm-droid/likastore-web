# Toasting

npm run build to build src
npm run build-dist to build dist
