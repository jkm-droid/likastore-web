### 1.0.0
Initial eggy release
### 1.0.2
* Added `max-width` to the core eggy styles. This is to stop eggy from expanding past the screen size on smaller devices.
### 1.0.3
* Added in new build process to make modifying eggy easier.
### 1.1.0
* Added animated progress bars to the popups.
### 1.2.0
* Titles and messages can now be disabled by passing `false` as an option.
* Remove progress bar styles if `styles` is set to false
### 1.3.0
* Added in ie-11 postcss plugins
### 1.3.1
* More ie11 styling fixes
### 1.3.2
* Small fixes to previous release